Please see the Email Use Cases [here](../../docs/use-cases/README.md#email-use-cases).
