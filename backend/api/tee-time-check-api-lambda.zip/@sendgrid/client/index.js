'use strict';

const client = require('./src/client');
const Client = require('./src/classes/client');

module.exports = client;
module.exports.Client = Client;
