import Response from "@sendgrid/helpers/classes/response";

export type ClientResponse = Response;
